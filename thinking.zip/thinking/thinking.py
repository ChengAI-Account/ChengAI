#!/usr/bin/env python3

# Install the dependent software packages :  pip install torch transformers  Optional Install numpy

import os
import torch
from transformers import AutoTokenizer, AutoModelForSequenceClassification

BASE_DIR = os.getcwd()
MODEL_DIR = os.path.join(BASE_DIR, "best_model")

device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
tokenizer = AutoTokenizer.from_pretrained(MODEL_DIR)
model = AutoModelForSequenceClassification.from_pretrained(MODEL_DIR).to(device).eval()

MAX_LEN = 16

def predict(name):
    name = name.strip().lower()
    enc = tokenizer(name, truncation=True, max_length=MAX_LEN,
                    padding="max_length", return_tensors="pt")
    ids = enc["input_ids"].to(device)
    mask = enc["attention_mask"].to(device)
    with torch.no_grad():
        logits = model(input_ids=ids, attention_mask=mask).logits
        prob = torch.softmax(logits, dim=1)[0].cpu().numpy()
    label = "Girl" if prob[1] > prob[0] else "Boy"
    conf = float(max(prob))
    return label, conf, {"Boy": float(prob[0]), "Girl": float(prob[1])}

if __name__ == "__main__":
    tests = ["小明", "Mike", "Mr Wang", "Mr John", "Parker", "小红", "小乐", "Patricia", "Cain", "Addy"]
    for n in tests:
        label, conf, probs = predict(n)
        print(f"{n:<10} -> {label}  conf={conf:.4f}  {probs}")